DROP TABLE IF EXISTS #__rantispam_tokens_prob;
DROP TABLE IF EXISTS #__rantispam_token_count;
DROP TABLE IF EXISTS #__rantispam_spams_detected;
DROP TABLE IF EXISTS #__rantispam_messages_hash;
DROP TABLE IF EXISTS #__rantispam_banip;
