DROP TABLE IF EXISTS `#__aimysitemap`;
DROP TABLE IF EXISTS `#__aimysitemap_crawl`;
DROP TABLE IF EXISTS `#__aimysitemap_kvstore`;
DROP TABLE IF EXISTS `#__aimysitemap_broken_links`;
