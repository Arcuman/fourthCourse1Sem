ALTER TABLE `#__aimysitemap_kvstore`
    MODIFY `k`
    varchar(64) NOT NULL COMMENT 'key';
