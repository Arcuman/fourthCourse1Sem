ALTER TABLE `#__aimysitemap_kvstore`
    MODIFY `v` longtext NOT NULL COMMENT 'value';
