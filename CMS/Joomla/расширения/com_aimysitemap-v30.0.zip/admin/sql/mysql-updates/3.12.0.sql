ALTER TABLE `#__aimysitemap_kvstore`
    MODIFY `v`
    mediumtext NOT NULL DEFAULT '' COMMENT 'value';
